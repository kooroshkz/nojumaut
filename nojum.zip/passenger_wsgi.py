import nojum.wsgi

application = myapp.wsgi.application